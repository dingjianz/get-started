<!--
 * @Autor: lycheng
 * @Date: 2019-12-20 10:25:31
 -->
## 准备
1.在demo中填写APPID、APISecret、APIKey，可到控制台-我的应用-在线语音合成（流式版）页面获取
2.安装nodejs

## 运行
1.打开cmd，进入demo目录，执行如下命令
 ```
 npm install
 npm run dev
 ```
2.在chrome浏览器中打开返回的地址，例如
http://127.0.0.1:8080/pages/iat-demo/index.html
ip和端口以执行“npm run dev”返回的信息为准
 
## 注意事项
1.请使用chrome浏览器测试。
2.如程序报错5位错误码，请到文档或错误码链接查询
  https://www.xfyun.cn/doc/tts/online_tts/API.html
  https://www.xfyun.cn/document/error-code


