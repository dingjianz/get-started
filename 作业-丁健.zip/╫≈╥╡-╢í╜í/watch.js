export function watchMethod(target, fields) {
  const handler = {
    get: function (target, key) {
      return target[key];
    },
    set: function (target, key, value) {
      if (fields[key] && typeof fields[key] === "function") {
        fields[key](value, target[key]);
      }
      target[key] = value;
    },
  };
  return new Proxy(target, handler);
}

const watchObj = watchMethod(
  { a: 1, b: 2 },
  {
    a: (val, oldVal) => {
      console.log(val, oldVal);
    },
  }
);
