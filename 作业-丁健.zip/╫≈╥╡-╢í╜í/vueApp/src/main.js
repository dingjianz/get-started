import { createApp } from "vue";
import App from "./App.vue";
import ElementPlus from "element-plus";
import "../node_modules/element-plus/lib/theme-chalk/index.css";
import Demo from "./components/Demo";

import "./index.css";

const app = createApp(App);
app.use(ElementPlus);
app.component("Demo", Demo);
app.mount("#app");
