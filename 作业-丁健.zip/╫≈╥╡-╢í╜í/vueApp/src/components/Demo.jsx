import { ref, reactive, watch } from "vue";

const SetUpObj = {
  setup() {
    const list = reactive([]);

    const reduce = ref(!!list.length);

    const removeArrayItem = () => {
      list.length = list.length - 1;
    };

    const addArrayItem = () => {
      list.push(list.length);
    };

    watch(
      () => list.length,
      () => {
        reduce.value = !!list.length;
      }
    );
    return () => (
      <div>
        <ul>
          {list.map((item) => {
            return <li>{item}</li>;
          })}
        </ul>
        {reduce.value && <button onClick={removeArrayItem}>remove item</button>}
        <button onClick={addArrayItem}>add item</button>
      </div>
    );
  },
};

export default SetUpObj;
