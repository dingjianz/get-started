<template>
  <div>
    <div>{{ title }}</div>
    <Demo />
  </div>
</template>

<script>
export default {
  setup() {
    const title = "Array Operate";
    return {
      title,
    };
  },
};
</script>
